/** Reference FX rates are only used for valuation, never passed off as stock quotes. */
export async function usdExchangeRate(currency: string): Promise<{ rate: number; date: string }> {
  if (currency === "USD") return { rate: 1, date: new Date().toISOString().slice(0, 10) };
  if (!/^[A-Z]{3}$/.test(currency)) throw new Error("Nicht unterstützte Kurswährung.");
  const res = await fetch(`https://api.frankfurter.dev/v1/latest?base=${currency}&symbols=USD`, {
    signal: AbortSignal.timeout(15000),
  });
  if (!res.ok) {
    console.error("Exchange rate request failed", res.status, await res.text());
    throw new Error("Dollar-Wechselkurs ist gerade nicht verfügbar.");
  }
  const data = await res.json() as { rates?: { USD?: number }; date?: string };
  const rate = data.rates?.USD;
  if (!rate || !Number.isFinite(rate) || !data.date) throw new Error("Kein gültiger Dollar-Wechselkurs verfügbar.");
  return { rate, date: data.date };
}