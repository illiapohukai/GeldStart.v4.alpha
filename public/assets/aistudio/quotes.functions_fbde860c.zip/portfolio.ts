import type { ExchangeQuote, MarketSource } from "./market";

export type Lot = { date: string; price: number; shares: number };
export type Position = {
  id: string;
  name: string;
  isin: string;
  symbol: string | null;
  source?: MarketSource;
  venue?: string;
  exchangeQuote?: ExchangeQuote;
  lots: Lot[];
  /** Simulated performance in % vs. first purchase price; null = use market price */
  perf: number | null;
  /** Manual price for stocks without an available market quote */
  manualPrice: number | null;
};
export type Depot = { id: string; name: string; createdAt: string; positions: Position[]; report?: { text: string; date: string } };

export const uid = () => Math.random().toString(36).slice(2, 10);

export const shares = (p: Position) => p.lots.reduce((s, l) => s + l.shares, 0);
export const invested = (p: Position) => p.lots.reduce((s, l) => s + l.shares * l.price, 0);
export const avgPrice = (p: Position) => (shares(p) ? invested(p) / shares(p) : 0);

export function currentPrice(p: Position, live: number | null | undefined): number {
  const base = p.lots[0]?.price ?? 0;
  if (p.perf !== null) return base * (1 + p.perf / 100);
  return live ?? p.manualPrice ?? base;
}

export function buy(p: Position, amountUsd: number, price: number, date = new Date().toISOString()): Position {
  if (!Number.isFinite(amountUsd) || !Number.isFinite(price) || amountUsd <= 0 || price <= 0) return p;
  return { ...p, lots: [...p.lots, { date, price, shares: amountUsd / price }] };
}

export type PurchaseMode = "amount" | "shares";

export function buyQuantity(p: Position, quantity: number, price: number, mode: PurchaseMode): Position {
  if (!Number.isFinite(quantity) || !Number.isFinite(price) || quantity <= 0 || price <= 0) return p;
  if (mode === "amount") return buy(p, quantity, price);
  if (!Number.isFinite(quantity * price)) return p;
  return { ...p, lots: [...p.lots, { date: new Date().toISOString(), price, shares: quantity }] };
}

export function duplicate(d: Depot, name: string): Depot {
  return {
    ...structuredClone(d),
    id: uid(),
    name,
    createdAt: new Date().toISOString(),
    positions: d.positions.map((p) => ({ ...structuredClone(p), id: uid() })),
  };
}

export function createDepot(name: string, positions: Position[] = []): Depot {
  return {
    id: uid(),
    name: name.trim() || "Neues Depot",
    createdAt: new Date().toISOString(),
    positions,
  };
}
