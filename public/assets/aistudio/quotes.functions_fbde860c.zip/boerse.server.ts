import { usdExchangeRate } from "./exchange-rates.server";
import type { ExchangeQuote } from "./market";

const BASE = "https://api.boerse-frankfurt.de/v1";
export type BoerseMatch = { isin: string; name: string; symbol: string | null; wkn: string };
type EquityRow = { isin?: string; wkn?: string; name?: { originalValue?: string } };
let directory: { until: number; rows: BoerseMatch[] } | null = null;
let pendingDirectory: Promise<BoerseMatch[]> | null = null;

export function parseEquities(value: unknown): BoerseMatch[] {
  const rows = (value as { data?: EquityRow[] } | null)?.data;
  if (!Array.isArray(rows)) return [];
  return rows.flatMap((row) => row.isin && /^[A-Z]{2}[A-Z0-9]{10}$/.test(row.isin) && row.name?.originalValue
    ? [{ isin: row.isin, name: row.name.originalValue, symbol: null, wkn: row.wkn ?? "" }] : []);
}

async function equities(offset: number, isins?: string[]) {
  const response = await fetch(`${BASE}/search/equity_search`, {
    method: "POST", headers: { Accept: "application/json", "Content-Type": "application/json" },
    body: JSON.stringify({ lang: "de", offset, limit: 300, sorting: "NAME", sortOrder: "ASC", ...(isins ? { isins } : {}) }),
    signal: AbortSignal.timeout(20000),
  });
  if (!response.ok) {
    console.error("Deutsche Börse search failed", response.status, await response.text());
    throw new Error("Deutsche Börse ist gerade nicht erreichbar.");
  }
  const data = await response.json() as { data?: EquityRow[]; recordsTotal?: number };
  if (!Array.isArray(data.data)) throw new Error("Deutsche Börse liefert derzeit keine Aktiensuche.");
  return data;
}

async function loadDirectory(): Promise<BoerseMatch[]> {
  if (directory && directory.until > Date.now()) return directory.rows;
  if (pendingDirectory) return pendingDirectory;
  pendingDirectory = (async () => {
    const first = await equities(0);
    const rows = parseEquities(first);
    const count = first.recordsTotal;
    if (!count || count > 30000) throw new Error("Aktienverzeichnis ist derzeit nicht verfügbar.");
    const offsets = Array.from({ length: Math.ceil(count / 300) - 1 }, (_, index) => (index + 1) * 300);
    for (let i = 0; i < offsets.length; i += 8) {
      const pages = await Promise.all(offsets.slice(i, i + 8).map((offset) => equities(offset)));
      pages.forEach((page) => rows.push(...parseEquities(page)));
    }
    directory = { until: Date.now() + 3600000, rows };
    return rows;
  })();
  try { return await pendingDirectory; } finally { pendingDirectory = null; }
}

export async function findBoerseStocks(query: string): Promise<BoerseMatch[]> {
  const normalized = query.trim().toUpperCase();
  if (/^[A-Z]{2}[A-Z0-9]{10}$/.test(normalized)) return parseEquities(await equities(0, [normalized]));
  const rows = await loadDirectory();
  const matches = rows.filter((row) => row.name.toUpperCase().includes(normalized) || row.wkn.toUpperCase() === normalized);
  matches.sort((a, b) => Number(b.name.toUpperCase() === normalized) - Number(a.name.toUpperCase() === normalized));
  return [...new Map(matches.map((row) => [row.isin, row])).values()].slice(0, 20);
}

export function parseQuoteEvent(text: string): { price: number; currency: string; time: string | null } | null {
  for (const line of text.split(/\r?\n/)) {
    if (!line.startsWith("data:")) continue;
    try {
      const data = JSON.parse(line.slice(5)) as { lastPrice?: number; currency?: { originalValue?: string }; timestampLastPrice?: string; tradedInPercent?: boolean };
      if (typeof data.lastPrice !== "number" || !Number.isFinite(data.lastPrice) || data.lastPrice <= 0 || data.tradedInPercent) continue;
      const currency = data.currency?.originalValue;
      if (!currency || !/^[A-Z]{3}$/.test(currency)) continue;
      return { price: data.lastPrice, currency, time: data.timestampLastPrice ?? null };
    } catch { /* heartbeat or incomplete event */ }
  }
  return null;
}

export async function fetchBoerseQuote(isin: string, venue: "XETR" | "XFRA"): Promise<ExchangeQuote> {
  const response = await fetch(`${BASE}/data/price_information?isin=${encodeURIComponent(isin)}&mic=${venue}`, {
    headers: { Accept: "text/event-stream" }, signal: AbortSignal.timeout(15000),
  });
  if (!response.ok) {
    console.error("Deutsche Börse quote failed", response.status, await response.text());
    throw new Error("Kurs von Deutsche Börse ist gerade nicht verfügbar.");
  }
  const reader = response.body?.getReader();
  if (!reader) throw new Error("Keine Kursdaten empfangen.");
  let text = "";
  const decoder = new TextDecoder();
  try {
    while (text.length < 100000) {
      const chunk = await reader.read();
      text += decoder.decode(chunk.value, { stream: !chunk.done });
      const boundary = text.lastIndexOf("\n");
      const quote = parseQuoteEvent(chunk.done ? text : text.slice(0, boundary));
      if (quote) {
        const fx = await usdExchangeRate(quote.currency);
        return { ...quote, usdRate: fx.rate };
      }
      if (chunk.done) break;
    }
  } finally { await reader.cancel().catch(() => {}); }
  throw new Error(`Kein letzter Aktienkurs auf ${venue === "XETR" ? "Xetra" : "Frankfurt"} verfügbar – anderen Handelsplatz versuchen.`);
}