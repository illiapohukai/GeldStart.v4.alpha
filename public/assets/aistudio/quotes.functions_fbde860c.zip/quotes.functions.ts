import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export type Quote = { symbol: string; price: number | null; time: string | null };

export const getNasdaqQuotes = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ symbols: z.array(z.string().max(10)).max(50) }).parse(d))
  .handler(async ({ data }): Promise<Quote[]> => {
    return Promise.all(
      data.symbols.map(async (symbol) => {
        try {
          const res = await fetch(
            `https://api.nasdaq.com/api/quote/${encodeURIComponent(symbol)}/info?assetclass=stocks`,
            { headers: { "User-Agent": "Mozilla/5.0", Accept: "application/json" } },
          );
          const j: any = await res.json();
          const raw: string | undefined = j?.data?.primaryData?.lastSalePrice;
          const price = raw ? parseFloat(raw.replace(/[$,]/g, "")) : NaN;
          return {
            symbol,
            price: Number.isFinite(price) ? price : null,
            time: j?.data?.primaryData?.lastTradeTimestamp ?? null,
          };
        } catch {
          return { symbol, price: null, time: null };
        }
      }),
    );
  });

export type SymbolMatch = { symbol: string; name: string };

/** Pure Hilfsfunktion: filtert und dedupliziert die Nasdaq-Autosuggest-Treffer. */
export function parseAutosuggest(j: unknown): SymbolMatch[] {
  const rows = Array.isArray((j as any)?.data) ? (j as any).data : [];
  const seen = new Set<string>();
  const out: SymbolMatch[] = [];
  for (const r of rows) {
    const m = r?.metadata ?? {};
    const sym = String(m.symbol ?? "");
    if (!sym || seen.has(sym)) continue;
    if (m.asset !== "STOCKS" || m.symbol_type !== "us") continue;
    if (!/^[A-Za-z.\-^]+$/.test(sym)) continue;
    seen.add(sym);
    out.push({ symbol: sym, name: String(m.updated_name ?? m.name ?? sym).replace(/\s+(Common Stock|Class [A-Z] Common Stock|American Depositary Shares).*$/i, "") });
    if (out.length >= 8) break;
  }
  return out;
}

export const searchNasdaqCompanies = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ query: z.string().min(2).max(60) }).parse(d))
  .handler(async ({ data }): Promise<SymbolMatch[]> => {
    try {
      const res = await fetch(
        `https://www.nasdaq.com/ai-search/external/content-search-bff/v1/autosuggest?query=${encodeURIComponent(data.query)}&limit=25&use_cache=true`,
        { headers: { "User-Agent": "Mozilla/5.0", Accept: "application/json" } },
      );
      return parseAutosuggest(await res.json());
    } catch {
      return [];
    }
  });

export const lookupNasdaqSymbol = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ symbol: z.string().min(1).max(10).regex(/^[A-Za-z.\-^]+$/) }).parse(d))
  .handler(async ({ data }): Promise<{ symbol: string; name: string; price: number } | { error: string }> => {
    const symbol = data.symbol.toUpperCase();
    try {
      const res = await fetch(
        `https://api.nasdaq.com/api/quote/${encodeURIComponent(symbol)}/info?assetclass=stocks`,
        { headers: { "User-Agent": "Mozilla/5.0", Accept: "application/json" } },
      );
      const j: any = await res.json();
      const raw: string | undefined = j?.data?.primaryData?.lastSalePrice;
      const price = raw ? parseFloat(raw.replace(/[$,]/g, "")) : NaN;
      if (!Number.isFinite(price)) return { error: `„${symbol}“ wurde auf nasdaq.com nicht gefunden.` };
      const name = String(j.data.companyName ?? symbol).replace(/\s+(Common Stock|Class [A-Z] Common Stock|American Depositary Shares).*$/i, "");
      return { symbol, name, price };
    } catch {
      return { error: "Nasdaq ist gerade nicht erreichbar." };
    }
  });
