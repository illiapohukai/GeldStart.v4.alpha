// The 25 stocks from the uploaded table. `symbol` = Nasdaq-listed US ticker;
// null when the stock is not traded on a US exchange covered by nasdaq.com.
export type StockDef = { name: string; isin: string; symbol: string | null; pdfEur: number };

export const EUR_USD_FALLBACK = 1.16;

export const STOCKS: StockDef[] = [
  { name: "Intuitive Surgical", isin: "US46120E6023", symbol: "ISRG", pdfEur: 384.45 },
  { name: "Symbotic", isin: "US87151X1019", symbol: "SYM", pdfEur: 35.22 },
  { name: "Hexagon", isin: "SE0015961909", symbol: null, pdfEur: 9.49 },
  { name: "Ubtech Robotics", isin: "CNE100006CQ4", symbol: null, pdfEur: 7.3 },
  { name: "Teradyne", isin: "US8807701029", symbol: "TER", pdfEur: 308.9 },
  { name: "AbCellera Biologics", isin: "CA00288U1066", symbol: "ABCL", pdfEur: 10.52 },
  { name: "Biontech", isin: "US09075V1026", symbol: "BNTX", pdfEur: 78.6 },
  { name: "Vertex Pharma", isin: "US92532F1003", symbol: "VRTX", pdfEur: 446.25 },
  { name: "Merck KGaA", isin: "DE0006599905", symbol: null, pdfEur: 144.35 },
  { name: "BB Biotech", isin: "CH0038389992", symbol: null, pdfEur: 52.5 },
  { name: "Grupo México", isin: "MXP370841019", symbol: null, pdfEur: 11.6 },
  { name: "MP Materials", isin: "US5533681012", symbol: "MP", pdfEur: 35.45 },
  { name: "Albemarle", isin: "US0126531013", symbol: "ALB", pdfEur: 85.74 },
  { name: "NexGen Energy", isin: "CA65340P1062", symbol: "NXE", pdfEur: 7.5 },
  { name: "Cameco", isin: "CA13321L1085", symbol: "CCJ", pdfEur: 72.56 },
  { name: "ABB", isin: "CH0012221716", symbol: null, pdfEur: 80.18 },
  { name: "NextEra Energy", isin: "US65339F1012", symbol: "NEE", pdfEur: 69.89 },
  { name: "CATL", isin: "CNE100006WS8", symbol: null, pdfEur: 50.11 },
  { name: "EnerSys", isin: "US29275Y1029", symbol: "ENS", pdfEur: 151.1 },
  { name: "Generac Holdings", isin: "US3687361044", symbol: "GNRC", pdfEur: 174.95 },
  { name: "KWS Saat", isin: "DE0007074007", symbol: null, pdfEur: 67.9 },
  { name: "CF Industries", isin: "US1252691001", symbol: "CF", pdfEur: 105.3 },
  { name: "Lindsay", isin: "US5355551061", symbol: "LNN", pdfEur: 95.5 },
  { name: "Novonesis", isin: "DK0060336014", symbol: null, pdfEur: 61.94 },
  { name: "Deere & Co", isin: "US2441991054", symbol: "DE", pdfEur: 563.2 },
];
