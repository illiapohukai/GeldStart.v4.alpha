import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { fetchBoerseQuote, findBoerseStocks } from "./boerse.server";
import type { BoerseMatch } from "./boerse.server";
import { priceInUsd } from "./market";
export type { BoerseMatch } from "./boerse.server";

const instrument = z.object({ isin: z.string().regex(/^[A-Z]{2}[A-Z0-9]{10}$/), venue: z.enum(["XETR", "XFRA"]) });

export const searchDeutscheBoerse = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => z.object({ query: z.string().trim().min(2).max(80) }).parse(data))
  .handler(async ({ data }): Promise<{ matches: BoerseMatch[] } | { error: string }> => {
    try { return { matches: await findBoerseStocks(data.query) }; }
    catch (error) { console.error("Boerse search", error); return { error: "Deutsche-Börse-Suche ist gerade nicht verfügbar. Bitte erneut versuchen." }; }
  });

export const lookupDeutscheBoerse = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => instrument.parse(data))
  .handler(async ({ data }) => {
    try {
      const [match] = await findBoerseStocks(data.isin);
      if (!match) return { error: "Diese ISIN wurde nicht als Aktie bei Deutsche Börse gefunden." };
      const quote = await fetchBoerseQuote(data.isin, data.venue);
      return { ...match, quote };
    } catch (error) {
      console.error("Boerse lookup", error);
      return { error: error instanceof Error ? error.message : "Kurs konnte nicht geladen werden." };
    }
  });

export const getDeutscheBoerseQuotes = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => z.object({ instruments: z.array(instrument).max(60) }).parse(data))
  .handler(async ({ data }) => Promise.all(data.instruments.map(async (item) => {
    const key = `DB:${item.isin}:${item.venue}`;
    try {
      const quote = await fetchBoerseQuote(item.isin, item.venue);
      return { key, price: priceInUsd(quote), quote };
    } catch (error) { console.error("Boerse refresh", item.isin, error); return { key, price: null, quote: null }; }
  })));