export type MarketSource = "nasdaq" | "deutsche-boerse";
export type ExchangeQuote = {
  price: number;
  currency: string;
  time: string | null;
  usdRate: number;
};

/** Source-qualified keys prevent ticker collisions across trading venues. */
export function quoteKey(p: { symbol: string | null; isin: string; source?: MarketSource; venue?: string }): string | null {
  return p.source === "deutsche-boerse" ? `DB:${p.isin}:${p.venue ?? "XETR"}` : p.symbol;
}

export function priceInUsd(quote: ExchangeQuote): number {
  if (!Number.isFinite(quote.price) || quote.price <= 0 || !Number.isFinite(quote.usdRate) || quote.usdRate <= 0) {
    throw new Error("Kein gültiger Kurs oder Wechselkurs verfügbar.");
  }
  return quote.price * quote.usdRate;
}